let _KendoUtility =
{
    GridPageSize: 10,

    ModalGridPageSize: 4,

    SetkendoDropDownList: function (dropDownId) {
        $(dropDownId).kendoDropDownList({});
    },

    SearchItemsInKendoTree: function (filterCtrl, treeCtrl, searchTextAr, searchTextEn, callBack) {

        let filterText = $(filterCtrl).val();
        let treeDepartments = $(treeCtrl).data("kendoTreeView");

        //  Filter  ----------------------------------
        let dataText = "";
        if (_CurrentLanguage == "ar-om") {
            dataText = searchTextAr;
        }
        else {
            dataText = searchTextEn;
        }
        if (filterText !== "") {
            treeDepartments.dataSource.filter({
                field: dataText,
                operator: "contains",
                value: filterText
            });
        } else {
            treeDepartments.dataSource.filter({});
        }

        // highlight  ----------------------------------
        // To remove highlight bind the tree or use Javascript
        // treeDepartments.setDataSource(_UCArchiveCenterContacts.DepartmentsDataSource);
        $('span.k-in > span.highlight').each(function () {
            $(this).parent().text($(this).parent().text());
        });

        // ignore if no search term
        if ($.trim(filterText) == '') {
            return;
        }

        let term = filterText.toUpperCase();
        let tlen = term.length;

        $(treeCtrl + ' span.k-in').each(function (index) {
            let text = $(this).text();
            let html = '';
            let q = 0;
            while ((p = text.toUpperCase().indexOf(term, q)) >= 0) {
                html += text.substring(q, p) + '<span class="highlight">' + text.substr(p, tlen) + '</span>';
                q = p + tlen;
            }

            if (q > 0) {
                html += text.substring(q);
                $(this).html(html);

                $(this).parentsUntil('.k-treeview').filter('.k-item').each(
                    function (index, element) {
                        $(treeCtrl).data('kendoTreeView').expand($(this));
                        $(this).data(filterCtrl, term);
                    });
            }
        });

        $(treeCtrl + ' .k-item').each(function () {
            if ($(this).data(filterCtrl) != term) {
                $(treeCtrl).data('kendoTreeView').collapse($(this));
            }
        });

        if (callBack != null && typeof callBack === "function") {
            callBack();
        }
    },

    GetMultiSelectItemTemplate: function (dataObj, showExpandOption, onExpandFun, id) {
        let template = "";
        // only add plus icon  for group or virtual group
        if (showExpandOption && (dataObj.ItemType == "groups" || dataObj.ItemType == "virtualGroups")) {
            // departments
            let expFunctin = onExpandFun + '(\'' + dataObj.Value + '\', \'' + id + '\',\'' + false + '\')"';

            if (dataObj.ItemType == "virtualGroups") {
                // virtual groups
                expFunctin = onExpandFun + '(\'' + dataObj.Value + '\', \'' + id + '\',\'' + true + '\')"';
            }

            template = '<span onclick="' + expFunctin +
                '<i class="far fa-plus-square fa-lg" data-toggle="tooltip" data-original-title="Expand department into users"></i></span>' +
                '<span class="selected-value-icon" style="background-image: url(\'' + _WebHostName + 'Theme/dist/img/cms/' + dataObj.Icon + '\') "></span>' + '<span>' + dataObj.Text + '</span>';
        }
        else {
            template = '<span class="selected-value-icon" style="background-image: url(\'' + _WebHostName + 'Theme/dist/img/cms/' + dataObj.Icon + '\') "></span><span>' + dataObj.Text + '</span>';
        }
        return template;
    },

    PrepareKendoMultiSelectWithIcon: function (id, textField, valueField, onChangeFun, showExpandOption, onExpandFun) {
        $(id).kendoMultiSelect({
            dataTextField: textField,
            dataValueField: valueField,
            //itemTemplate: '<span class="selected-value-icon" style="background-image: url(\'' + _WebHostName + 'Theme/dist/img/cms/#:data.Icon#\')"></span><span>#:data.Text#</span>',
            //tagTemplate: '<span class="selected-value-icon" style="background-image: url(\'' + _WebHostName + 'Theme/dist/img/cms/#:data.Icon#\')"></span><span>#:data.Text#</span>',
            itemTemplate: function (dataItem) {
                return _KendoUtility.GetMultiSelectItemTemplate(dataItem, showExpandOption, onExpandFun, id);
            },
            tagTemplate: function (dataItem) {
                return _KendoUtility.GetMultiSelectItemTemplate(dataItem, showExpandOption, onExpandFun, id);
            },
            autoBind: false,
            minLength: 3,
            datasource: [],
            value: [],
            change: onChangeFun
        });
    },

    PrepareKendoMultiSelect: function (id, placeHolder, dataText, dataValue, dataSource, selectedValue, onChangeFun) {
        let multiSelect = $(id).kendoMultiSelect({
            placeholder: placeHolder,
            dataTextField: dataText,
            dataValueField: dataValue,
            //autoBind: false,
            dataSource: null,
            value: null,
            change: onChangeFun
        }).data("kendoMultiSelect");

        if (dataSource) {
            multiSelect.setDataSource(dataSource);
        }

        if (selectedValue) {
            multiSelect.value(selectedValue);
        }

    },

    SetSelectedValueKendoMultiSelect: function (id, selectedValue) {
        let multiSelect = $(id).data("kendoMultiSelect");
        multiSelect.value(selectedValue);
    },

    BindKendoMultiSelect: function (id, dataSource) {
        let multiSelect = $(id).data("kendoMultiSelect");
        multiSelect.setDataSource(dataSource);
        multiSelect.value(dataSource);
    },

    BindDataSourceKendoMultiSelect: function (id, dataSource) {
        let multiSelect = $(id).data("kendoMultiSelect");
        multiSelect.setDataSource(dataSource);

    },

    BindDataSourceKendoMultiSelectWithSelectedData: function (id, dataSource, selectedData) {
        let multiSelect = $(id).data("kendoMultiSelect");
        multiSelect.setDataSource(dataSource);
        multiSelect.dataSource.filter({});
        multiSelect.value(selectedData);
    },

    BindKendoMultiSelectForAutoComplete: function (id, dataSource, callBack) {
        let multiSelect = $(id).data("kendoMultiSelect");
        multiSelect.setDataSource(dataSource);
        multiSelect.value(dataSource);
        if (callBack != null) {
            callBack();
        }
    },

    BindKendoMultiSelectWithFilter: function (id, data) {
        let multiSelect = $(id).data("kendoMultiSelect");

        let dataSource = new kendo.data.DataSource({
            data: data
        });

        multiSelect.setDataSource(dataSource);

        multiSelect.dataSource.filter({});
        multiSelect.value(data);
    },

    PrepareDropDownList: function (dropDownId, datasource, onSelect) {

        _KendoUtility.DestroyKendoDropdown(dropDownId);
        let dropdownList = $(dropDownId).kendoDropDownList({
            optionLabel: "",
            dataTextField: "Text",
            dataValueField: "Value",
            template: '<span class="selected-value-icon" style="background-image: url(\'' + _WebHostName + 'Theme/dist/img/cms/#:data.Icon#\')"></span><span>#:data.Text#</span>',
            valueTemplate: '<span class="selected-value-icon" style="background-image: url(\'' + _WebHostName + 'Theme/dist/img/cms/#:data.Icon#\')"></span><span>#:data.Text#</span>',
            dataSource: datasource,
            select: onSelect
        }).data("kendoDropDownList");

        let count = dropdownList.dataSource.data().length;
        if (count > 1) {
            dropdownList.setOptions({ optionLabel: { Text: _CMSResourcesManager.lblAll, Value: -1 } });
            dropdownList.value(-1);
        }
    },

    BindDropDownList: function (id, dataSource) {
        let dropdownList = $(id).data("kendoDropDownList");
        dropdownList.setDataSource(dataSource);
        const count = dropdownList.dataSource.data().length;

        if (count == 1) {
            dropdownList.select(0);
        }
        else if (count > 1) {
            dropdownList.setOptions({ optionLabel: { Text: _CMSResourcesManager.lblAll, Value: -1 } });
            dropdownList.value(-1);
        }
    },

    DestroyKendoGrid: function (selector) {
        const gv = $(selector).data("kendoGrid");
        if (typeof gv != 'undefined') {
            gv.destroy();
            $(selector).empty();
        }
    },

    DestroyKendoTree: function (treeId) {
        //Destroying the Widget Manually
        if ($(treeId).data("kendoTreeView") != null) {
            $(treeId).data('kendoTreeView').destroy();
            $(treeId).html('');
        }
    },

    DestroyKendoDiagram: function (selector) {
        let diagram = $(selector).data("kendoDiagram");
        if (diagram != null) {
            diagram.destroy();
        }
    },

    SetKendoDiagramZoom: function (diagramSelector, zoomType) {
        let diagram = $(diagramSelector).getKendoDiagram();
        if (zoomType == "plus") {
            diagram.zoom(diagram.zoom() + 0.1);
        }
        else {
            diagram.zoom(diagram.zoom() - 0.1);
        }
    },

    SetDiagramHorizontalScrollProperties: function (diagramSelector, diagramParentSelector) {
        let kendoDiag = $(diagramSelector);
        //Disable mouse zoomin/zoomout
        kendoDiag.unbind("mousewheel");
        kendoDiag.unbind("DOMMouseScroll");
        //set full width if there is no horizontal scroll bar otherwise set scroll position at the center of outer div
        let divDiagramParent = $(diagramParentSelector);
        if (kendoDiag.width() <= divDiagramParent.width()) {
            kendoDiag.width("auto");
        }
        else {
            divDiagramParent.scrollLeft((kendoDiag.width() - divDiagramParent.width()) / 2);
        }
    },

    ClearKendoMultiSelect: function (id) {
        let elementMultiSelect = $(id).data("kendoMultiSelect");
        if (typeof elementMultiSelect != 'undefined' && elementMultiSelect != null) {
            let multiselect = $(id).data("kendoMultiSelect");
            multiselect.value("");
            multiselect.trigger("change");
        }
    },

    DestroyKendoDropdown: function (dropDownId) {
        let dropDownList = $(dropDownId).data("kendoDropDownList");
        if (dropDownList != null) {
            dropDownList.select(-1);
            dropDownList.refresh();
            dropDownList.destroy();
        }
    },

    DestroyKendoMultiSelect: function (multiSelectId) {
        let multiselect = $(multiSelectId).data("kendoMultiSelect");
        if (multiselect != null) {
            multiselect.destroy();
            $(multiSelectId).empty();
        }
    },

    DestroyKendoTimePicker: function (timePickerId) {
        let timePicker = $(timePickerId).data("kendoTimePicker");
        if (timePicker != null) {
            // detach events
            timePicker.destroy();
        }
    },

    ClearSelectedItemKendoDropdown: function (dropDownId) {
        let dropDownList = $(dropDownId).data("kendoDropDownList");
        if (dropDownList != null) {
            dropDownList.select(-1);
            dropDownList.refresh();
        }
    },

    ClearKendoDropdownDataSource: function (dropDownId) {
        let dropDownList = $(dropDownId).data("kendoDropDownList");
        if (dropDownList != null) {
            dropDownList.select(-1);
            dropDownList.setDataSource(null);
            dropDownList.refresh();
        }
    },

    ClearkendoGrid: function (gridId) {
        let grid = $(gridId).data("kendoGrid");
        if (grid != null) {
            grid.setDataSource(null);
        }
    },

    GetGridTotalRecoreds: function (gridId) {
        let totalRecords = 0;
        let grid = $(gridId).data("kendoGrid");
        // grid.dataSource.read();
        //total records
        totalRecords = grid.dataSource.total();

        return totalRecords;
    },

    InitializeKendoEditor: function (id, onChange) {

        $(id).kendoEditor({
            change: onChange,
            enable: false,
            stylesheets:
                [
                    _WebHostName + "Theme/plugins/kendoui/editor.css",
                ],
            tools: [
                "bold",
                "insertImage",
                {
                    name: "myInsertImage",
                    tooltip: "Upload Image",
                    exec: function (e) {
                        let uploadInput = $("<input type='file' />");
                        uploadInput.click();
                        uploadInput.on("change", _HelperManager.uploadInputChange);
                    }
                },
                "italic",
                "underline",
                "justifyLeft",
                "justifyCenter",
                "justifyRight",
                "insertUnorderedList",
                "createLink",
                "unlink",
                "tableWizard",
                "createTable",
                "addRowAbove",
                "addRowBelow",
                "addColumnLeft",
                "addColumnRight",
                "deleteRow",
                "deleteColumn",
                "mergeCellsHorizontally",
                "mergeCellsVertically",
                "splitCellHorizontally",
                "splitCellVertically",
                "formatting",

                {
                    name: "fontName",
                    template: $("#custom-template").html(),
                    items: [
                        { text: "Andale Mono", value: "Andale Mono" },
                        { text: "Arial", value: "Arial" },
                        { text: "Arial Black", value: "Arial Black" },
                        { text: "Book Antiqua", value: "Book Antiqua" },
                        { text: "Comic Sans MS", value: "Comic Sans MS" },
                        { text: "Courier New", value: "Courier New" },
                        { text: "Georgia", value: "Georgia" },
                        { text: "Helvetica", value: "Helvetica" },
                        { text: "Impact", value: "Impact" },
                        { text: "Symbol", value: "Symbol" },
                        { text: "Tahoma", value: "Tahoma" },
                        { text: "Terminal", value: "Terminal" },
                        { text: "Times New Roman", value: "Times New Roman" },
                        { text: "Trebuchet MS", value: "Trebuchet MS" },
                        { text: "Verdana", value: "Verdana" },
                    ]
                },
                "fontSize",
                "foreColor",
                "backColor",
            ]
        });


        let editorBody = $($(id).getKendoEditor().body);
        if (editorBody) {
            let fontSize = "14pt";
            if (_CMSConfigManager != "undefined"
                && _CMSConfigManager.CMSSettingKeys != "undefined"
                && typeof _CMSConfigManager.CMSSettingKeys.DefaultEditorFontSize != "undefined"
                && _CMSConfigManager.CMSSettingKeys.DefaultEditorFontSize != "") {
                fontSize = _CMSConfigManager.CMSSettingKeys.DefaultEditorFontSize;
            }

            editorBody.css("font-size", fontSize);
        }
    },

    InitializeKendoEditorForSignatureTemplate: function (id, customtemplateId, onChange) {

        $(id).kendoEditor({
            change: onChange,
            enable: false,
            stylesheets:
                [
                    _WebHostName + "Theme/plugins/kendoui/editor.css",
                ],
            tools: [
                "bold",
                "italic",
                "justifyLeft",
                "justifyCenter",
                "justifyRight",
                /* "fontSize",*/
                "foreColor",
                /* "backColor",*/
                {
                    name: "fontSize",
                    items: [
                        { text: "12pt", value: "12pt" },
                        { text: "14pt", value: "14pt" },
                        { text: "16pt", value: "16pt" },
                        { text: "18pt", value: "18pt" }
                    ]
                },
                {
                    name: "fontName",
                    template: $(customtemplateId).html(),
                    items: [
                        { text: "Times New Roman", value: "Times New Roman" },
                        { text: "Tahoma", value: "Tahoma" },
                        { text: "Andale Mono", value: "Andale Mono" },
                        { text: "Arial", value: "Arial" },
                        { text: "Arial Black", value: "Arial Black" },
                        { text: "Book Antiqua", value: "Book Antiqua" },
                        { text: "Comic Sans MS", value: "Comic Sans MS" },
                        { text: "Courier New", value: "Courier New" },
                        { text: "Georgia", value: "Georgia" },
                        { text: "Helvetica", value: "Helvetica" },
                        { text: "Impact", value: "Impact" },
                        { text: "Symbol", value: "Symbol" },
                        { text: "Terminal", value: "Terminal" },
                        { text: "Trebuchet MS", value: "Trebuchet MS" },

                    ]
                },
            ]
        });


        let editorBody = $($(id).getKendoEditor().body);
        if (editorBody) {
            let fontSize = "14pt";
            if (_CMSConfigManager != "undefined"
                && _CMSConfigManager.CMSSettingKeys != "undefined"
                && typeof _CMSConfigManager.CMSSettingKeys.DefaultEditorFontSize != "undefined"
                && _CMSConfigManager.CMSSettingKeys.DefaultEditorFontSize != "") {
                fontSize = _CMSConfigManager.CMSSettingKeys.DefaultEditorFontSize;
            }

            editorBody.css("font-size", fontSize);
        }
    },

    SetKendoRTLDirection: function () {
        // Set RTL For KendoUI
        let body = $('body');
        if (typeof body !== "undefined") {
            if (_CurrentLanguage == "ar-om") {
                if (!body.hasClass('k-rtl')) {
                    body.addClass('hold-transition sidebar-mini layout-fixed sidebar-collapse k-rtl');
                }
            }

        }
    },

    SetKendoCulture: function () {

        if (_CurrentLanguage == "en-us") {
            kendo.culture("en-US");
        }
        else {
            kendo.culture("ar-OM");
        }
    },

    SetDataOriginalTitleForkendoToolTip: function () {

        //set data-original-title attribute for kendo tool tip
        const start = 0;
        let lstDataOriginalTitle = document.querySelectorAll("[data-original-title]");
        for (let i = start; i < lstDataOriginalTitle.length; i++) {
            let attTitle = lstDataOriginalTitle[i].getAttribute("data-original-title");
            let attTitleValue = _CMSResourcesManager[attTitle];
            if (attTitleValue != null) {
                $(lstDataOriginalTitle[i]).attr("data-original-title", attTitleValue);
            }
        }

        const x = 0;
        let lstDataOriginalPlaceHolder = document.querySelectorAll("[data-original-Placeholder]");
        for (let i = x; i < lstDataOriginalPlaceHolder.length; i++) {
            let attPlaceholderTitle = lstDataOriginalPlaceHolder[i].getAttribute("data-original-Placeholder");
            let attPlaceHolderValue = _CMSResourcesManager[attPlaceholderTitle];
            if (attPlaceHolderValue != null) {
                $(lstDataOriginalPlaceHolder[i]).attr("placeholder", attPlaceHolderValue);
            }
        }

    },

    SetKendoAutoComplete: function (controlId, dataTextField, dataSource, selectFunction, changeFunction) {
        $(controlId).kendoAutoComplete(
            {
                dataSource: dataSource,
                dataTextField: dataTextField,
                select: selectFunction,
                change: changeFunction,
            });
    },

    FireSearchKendoAutoComplete: function (controlId) {
        let autocomplete = $(controlId).data("kendoAutoComplete");
        autocomplete.search();
    },

    DisableEnableKendoAutoComplete: function (controlId, isEnable) {
        $(controlId).kendoAutoComplete(
            {
                enable: isEnable
            });
    },

    ClearKendoEditor: function (id) {

        let editor = $(id).data('kendoEditor');
        if (typeof (editor) !== 'undefined' && editor != null) {
            editor.value(null);
        }

    },

    SetKendoOrgChartZoom: function (orgChartSelector, zoomType) {
        let orgChart = $(orgChartSelector);
        let currentZoom = orgChart.css('zoom');
        if (currentZoom < 0) {
            return;
        }
        if (zoomType == "plus") {
            orgChart.css('zoom', parseFloat(currentZoom) + 0.1);
        }
        else {
            orgChart.css('zoom', parseFloat(currentZoom) - 0.1);
        }
    },

    SetKendoGridHeight: function () {
        const marginH = 100;
        let windowH = $(window).height();
        let headerFooterH = $(".main-header").outerHeight() + $("footer").outerHeight();
        let gridHeight = windowH - (headerFooterH + marginH);
        return gridHeight;
    },

    DisableEnableKendoDropdown: function (id, isEnable) {
        let dropdownlist = $(id).data("kendoDropDownList");
        dropdownlist.enable(isEnable);
    }
};