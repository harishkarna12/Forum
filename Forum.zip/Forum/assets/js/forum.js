CKEDITOR.replace('editor1');



$(document).ready(function () {

    var soruceboxData = [
        { text: "Select One", value: "0" },
        { text: "Case", value: "C" },
        { text: "Record Folder", value: "F" },
        { text: "Correspondence", value: "CP" },
        { text: "Direct", value: "D" }
    ];
    var categoryboxData = [
        { text: "General", value: "0" },
        { text: "General", value: "C" },
        { text: "Staff", value: "F" },
        { text: "Site Feedback", value: "CP" },

    ];
    var correspondacysectionData = [
        { text: "Select One", value: "0" },
        { text: "Correspondence1", value: "C" },
        { text: "Correspondence2", value: "F" },
        { text: "Correspondence3", value: "CP" },
        { text: "Correspondence4", value: "D" }
    ];

    var soruceselectfoldersectionData = [
        { text: "Select One", value: "0" },
        { text: "Record Folder1", value: "C" },
        { text: "Record Folder2", value: "F" },
        { text: "Record Folder3", value: "CP" },
        { text: "Record Folder4", value: "D" }
    ];
    var soruceselectsectionData = [
        { text: "Select One", value: "0" },
        { text: "Case1", value: "CA" },
        { text: "Case2", value: "FO" },
        { text: "Case3", value: "COP" },
        { text: "Case4", value: "DT" }

    ];
    


    var titleboxData = [
        { text: "Select One", value: "0" },
        { text: "Case", value: "C" },
        { text: "Record Folder", value: "F" },
        { text: "Correspondence", value: "CP" },
        { text: "Direct", value: "D" }
    ];
    var documenttypeboxData = [
        { text: "Select One", value: "0" },
        { text: "Letter", value: "C" },
        { text: "Office Order", value: "F" },
        { text: "Internal Letter", value: "CP" },
        { text: "Announcemnets", value: "A" },
        { text: "Decisions", value: "D" },
        { text: "Reports", value: "D" }
    ];
    var lettertypeboxData = [
        { text: "Letter", value: "0" },
        { text: "Letter", value: "C" },
        { text: "Office Order", value: "F" },
        { text: "Announcements", value: "CP" },
        { text: "Reports", value: "D" }
    ];
    var securitylevelboxData = [
        { text: "Restricted", value: "0" },
        { text: "Restricted", value: "C" },
        { text: "Unclassified", value: "F" },
        { text: "Confidential", value: "CP" },
        { text: "Secret", value: "D" }
    ];


    $("#soruceboxdrop").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: soruceboxData
    });
    $("#categoryboxdrop").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: categoryboxData
    });
    $("#soruceselectfoldersection").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: soruceselectfoldersectionData
    });

    $("#titleboxdrop").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: titleboxData
    });
    $("#soruceselectsection").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: soruceselectsectionData
    });
    
    $("#correspondacysection").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: correspondacysectionData
    });
    

    $("#documenttypeboxdrop").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: documenttypeboxData
    });
    $("#lettertypeboxdrop").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: lettertypeboxData
    });
    $("#securitylevelboxdrop").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: securitylevelboxData
    });
    var categorysecData = [

        { text: "General", value: "G" },
        { text: "Staff", value: "S" },
        { text: "Site Feedback", value: "SF" }
    ];

    $("#categoryDropDown2").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: categorysecData
    });

    $("#perdontagg").kendoMultiSelect({
        autoClose: false
    });
    $("#datepicker").kendoDatePicker({
        dateInput: true
    });
    $("#datepickertodate").kendoDatePicker({
        dateInput: true
    });
    
    var statusData = [

        { text: "Open", value: "O" },
        { text: "Closed", value: "C" },
        { text: "Reopened", value: "RO" },
        { text: "Archived", value: "A" }

    ];
    $("#status").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: statusData
    });
    var soruceboxdropData = [
        { text: "Select One", value: "0" },
        { text: "Case", value: "C" },
        { text: "Record Folder", value: "F" },
        { text: "Correspondence", value: "CP" },
        { text: "Direct", value: "D" }

    ];
    $("#sorucebox").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: soruceboxdropData
    });
    var otherDocumentData = [
        { text: "Select One", value: "0" },
        { text: "PDF", value: "A" },
        { text: "DOC", value: "B" },
        { text: "JPG", value: "C" },
        { text: "PNG", value: "D" }

    ];
    $("#otherDocumentDropdown").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: otherDocumentData
    });


    $("#rdb1, #rdb2").change(function () {
        if ($("#rdb1").is(":checked")) {
            $("#uploadfile").show();
            $("#cormsfile").hide();
        } else if ($("#rdb2").is(":checked")) {
            $("#cormsfile").show();
            $("#uploadfile").hide();
        }
    });
    $("#status").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: statusData
    });
    var categoryboxdropData = [
        { text: "General", value: "0" },
        { text: "General", value: "C" },
        { text: "Staff", value: "F" },
        { text: "Site Feedback", value: "CP" },


    ];
    $("#categorybox").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: categoryboxdropData
    });

    $("#status").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: statusData
    });
    var titleboxdropData = [
        { text: "Select One", value: "0" },
        { text: "Case", value: "C" },
        { text: "Record Folder", value: "F" },
        { text: "Correspondence", value: "CP" },
        { text: "Direct", value: "D" }

    ];
    $("#titlebox").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: titleboxdropData
    });
    $("#status").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: statusData
    });
    var dropData = [
        { text: "Select One", value: "0" },
        { text: "Case", value: "C" },
        { text: "Record Folder", value: "F" },
        { text: "Correspondence", value: "CP" },
        { text: "Direct", value: "D" }

    ];
    $("#documenttypebox").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: documenttypeboxdropData
    });
    $("#status").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: statusData
    });
    var lettertypeboxdropData = [
        { text: "Letter", value: "0" },
        { text: "Letter", value: "C" },
        { text: "Office Order", value: "F" },
        { text: "Announcements", value: "CP" },
        { text: "Reports", value: "D" }

    ];
    $("#lettertypebox").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: lettertypeboxdropData
    });

    $("#status").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: statusData
    });
    var securitylevelboxdropData = [
        { text: "Restricted", value: "0" },
        { text: "Restricted", value: "C" },
        { text: "Unclassified", value: "F" },
        { text: "Confidential", value: "CP" },
        { text: "Secret", value: "D" }

    ];
    $("#securitylevelbox").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: securitylevelboxdropData
    });
    var dataSource = new kendo.data.DataSource({
        data: [
            { Id: 1, tag: "book" },
            { Id: 2, tag: "india" },
            { Id: 3, tag: "sample" },
            { Id: 4, tag: "newindia" },
            { Id: 5, tag: "books" },

        ],
        sort: { field: "tag", dir: "asc" }
    });

    $("#multiselecttag").kendoMultiSelect({
        dataTextField: "tag",
        dataValueField: "Id",
        dataSource: dataSource,
        filter: "contains",
        placeholder: "Please select Tag",
        downArrow: true,
        noDataTemplate: $("#noDataTemplate").html(),

    });
    var dataSourcee = new kendo.data.DataSource({
        data: [
            { Id: 1, tag: "book" },
            { Id: 2, tag: "india" },
            { Id: 3, tag: "sample" },
            { Id: 4, tag: "newindia" },
            { Id: 5, tag: "books" },

        ],
        sort: { field: "tag", dir: "asc" }

    });
    $("#multiselecttagg").kendoMultiSelect({
        dataTextField: "tag",
        dataValueField: "Id",
        dataSource: dataSourcee,
        filter: "contains",
        placeholder: "Please select Tag",
        downArrow: true,
        noDataTemplate: $("#noDataTemplate").html(),

    });
    
    $("#status").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: statusData
        });
        var soruceboxdropData = [
            { text: "Select One", value: "0" },
            { text: "Case", value: "C" },
            { text: "Record Folder", value: "F" },
            { text: "Correspondence", value: "CP" },
            { text: "Direct", value: "D" }
    
        ];
        $("#sorucebox").kendoDropDownList({
            dataTextField: "text",
            dataValueField: "value",
            dataSource: soruceboxdropData
        });
        var otherDocumentData= [
            { text: "Select One", value: "0" },
            { text: "PDF", value: "A" },
            { text: "DOC", value: "B" },
            { text: "JPG", value: "C" },
            { text: "PNG", value: "D" }
    
        ];
        $("#otherDocumentDropdown").kendoDropDownList({
            dataTextField: "text",
            dataValueField: "value",
            dataSource: otherDocumentData
        });
     
        
        $("#rdb1, #rdb2").change(function () {
            if ($("#rdb1").is(":checked")) {
                $("#uploadfile").show();
                $("#cormsfile").hide();
            } else if ($("#rdb2").is(":checked")) {
                $("#cormsfile").show();
                $("#uploadfile").hide();
            }
        });
        $("#status").kendoDropDownList({
            dataTextField: "text",
            dataValueField: "value",
            dataSource: statusData
            });
            var categoryboxdropData = [
                { text: "General", value: "0" },
                { text: "General", value: "C" },
                { text: "Staff", value: "F" },
                { text: "Site Feedback", value: "CP" },
                
        
            ];
            $("#categorybox").kendoDropDownList({
                dataTextField: "text",
                dataValueField: "value",
                dataSource: categoryboxdropData
            });
          
                $("#status").kendoDropDownList({
                    dataTextField: "text",
                    dataValueField: "value",
                    dataSource: statusData
                    });
                    var titleboxdropData = [
                        { text: "Select One", value: "0" },
                        { text: "Case", value: "C" },
                        { text: "Record Folder", value: "F" },
                        { text: "Correspondence", value: "CP" },
                        { text: "Direct", value: "D" }
                
                    ];
                    $("#titlebox").kendoDropDownList({
                        dataTextField: "text",
                        dataValueField: "value",
                        dataSource: titleboxdropData
                    });
                    $("#status").kendoDropDownList({
                        dataTextField: "text",
                        dataValueField: "value",
                        dataSource: statusData
                        });
                        var documenttypeboxdropData = [
                            { text: "Select One", value: "0" },
                            { text: "Letter", value: "C" },
                            { text: "Office Order", value: "F" },
                            { text: "Internal Letter", value: "CP" },
                            { text: "Announcements", value: "D" },
                            { text: "Decisions", value: "D" },
                            { text: "Reports", value: "D" }

                    
                        ];
                        $("#documenttypebox").kendoDropDownList({
                            dataTextField: "text",
                            dataValueField: "value",
                            dataSource: documenttypeboxdropData
                        });
                        $("#status").kendoDropDownList({
                            dataTextField: "text",
                            dataValueField: "value",
                            dataSource: statusData
                            });
                            var lettertypeboxdropData = [
                                { text: "Letter", value: "0" },
                                { text: "Letter", value: "C" },
                                { text: "Office Order", value: "F" },
                                { text: "Announcements", value: "CP" },
                                { text: "Reports", value: "D" }
                        
                            ];
                            $("#lettertypebox").kendoDropDownList({
                                dataTextField: "text",
                                dataValueField: "value",
                                dataSource: lettertypeboxdropData
                            });

                            $("#status").kendoDropDownList({
                                dataTextField: "text",
                                dataValueField: "value",
                                dataSource: statusData
                                });
                                var securitylevelboxdropData = [
                                    { text: "Restricted", value: "0" },
                                    { text: "Restricted", value: "C" },
                                    { text: "Unclassified", value: "F" },
                                    { text: "Confidential", value: "CP" },
                                    { text: "Secret", value: "D" }
                            
                                ];
                                $("#securitylevelbox").kendoDropDownList({
                                    dataTextField: "text",
                                    dataValueField: "value",
                                    dataSource: securitylevelboxdropData
                                });
    $("#grid").kendoGrid({
        dataSource: {


            data: forum,
            schema: {
                model: {
                    fields: {
                        Topic: { type: "string" },
                        Null: { type: "string" },
                        Repiles: { type: "number" },
                        status: { type: "string" },
                        Activity: { type: "string" }
                    }
                }
            },
            pageSize: 20
        },
        toolbar: ["search"],

        height: 750,
        scrollable: false,
        sortable: true,
        filterable: false,
        pageable: {
            input: true,
            numeric: false
        },
        columns: [

            {
                field: "Topic", title: "Topics", width: "400px", template: function (dataItem) {
                    return dataItem.Topic;
                }
            },
            {
                field: "", title: "", width: "100px", template: function (dataItem) {
                    return dataItem.Null;
                }
            },
            { field: "Repiles", title: "Replies", width: "100px" },
            { field: "status", title: "Status", width: "100px" },
            { field: "Activity", width: "50px" }
        ]
    });

    $("#threadtable").kendoGrid({
        dataSource: {


            data: forum,
            schema: {
                model: {
                    fields: {
                        Topic: { type: "string" },
                        Null: { type: "string" },
                        Repiles: { type: "number" },
                        status: { type: "string" },
                        Activity: { type: "string" }
                    }
                }
            },
            pageSize: 20
        },
        toolbar: ["search"],

        height: 500,
        scrollable: true,
        sortable: true,
        filterable: false,
        pageable: {
            input: true,
            numeric: false
        },
        columns: [

            {
                field: "Topic", title: "Topics", width: "400px", template: function (dataItem) {
                    return dataItem.Topic;
                }
            },
            {
                field: "", title: "", width: "100px", template: function (dataItem) {
                    return dataItem.Null;
                }
            },
            { field: "Repiles", title: "Replies", width: "100px" },
            { field: "status", title: "Status", width: "100px" },
            { field: "Activity", width: "50px" }
        ]
    });
    /* outcome table script*/

    $("#outcome").kendoGrid({
        dataSource: {


            data: outcomedata,
            schema: {
                model: {
                    fields: {
                        Categories: { type: "string" },
                        Outcome: { type: "string" },


                        // View: { type: "number" },
                        // Activity: { type: "string" }
                    }

                }
            },
            pageSize: 20
        },
        toolbar: ["search"],

        height: 300,
        scrollable: true,
        sortable: true,
        filterable: false,
        pageable: {
            input: true,
            numeric: false
        },
        columns: [
            {
                field: "Categories", title: "Categories", width: "100px", template: function (dataItem) {
                    return dataItem.Categories;
                }
            },

            {
                field: "Outcome", title: "Outcome", width: "400px", template: function (dataItem) {
                    return dataItem.Outcome;
                }
            },


            // {
            //     field: "", title: "", width: "100px", template: function (dataItem) {
            //         return dataItem.Null;
            //     }
            // },

            // {
            //     field: "Categories", title: "Categories", width: "400px", template: function (dataItem) {
            //         return dataItem.Outcome;
            //     }
            // },

            // { field: "View", title: "View", width: "50px" },
            // { field: "Activity", width: "50px" }
        ]
    });


    ///for reopen starts///
    $("#reopenout").kendoGrid({
        dataSource: {


            data: outcomedata,
            schema: {
                model: {
                    fields: {
                        Categories: { type: "string" },
                        Outcome: { type: "string" },


                        // View: { type: "number" },
                        // Activity: { type: "string" }
                    }

                }
            },
            pageSize: 20
        },
        toolbar: ["search"],

        height: 300,
        scrollable: true,
        sortable: true,
        filterable: false,
        pageable: {
            input: true,
            numeric: false
        },
        columns: [
            {
                field: "Categories", title: "Categories", width: "100px", template: function (dataItem) {
                    return dataItem.Categories;
                }
            },

            {
                field: "Outcome", title: "Outcome", width: "400px", template: function (dataItem) {
                    return dataItem.Outcome;
                }
            },

            // {
            //     field: "Action",
            //     title: "Action",
            //     width: "130px",
            //     template: "<a class=' k-button-icontext k-grid-edit' href='javascript:void(0)' onclick='openDrawer()'><i class='fa fa-pencil'></i></a>"
            // }

        ]
    });

    ////reopen ends///
    $("#soruceselect").change(function () {
        $(this).val() == "V"
        {
            $("#attachdocument").show();

            $("#addtopic").hide();
        }
    });
    $("#backbtn").click(function () {
        $("#addtopic").show();
        $("#attachdocument").hide();

    })



    showSelectedDiv();
    function addNewItem() {
        var value = document.getElementById('valuePlaceholder').innerText;

        console.log("Add new item function called with value:", value);

        document.getElementById('valuePlaceholder').innerText = "New Item";

        addNew('someID', 'New Item');
    }

    $('input[type=radio][name=radio]').change(function () {
        showSelectedDiv();
    });
    function showSelectedDiv() {
        var selectedValue = $('input[type=radio][name=radio]:checked').val();

        $('#uploadfile').hide();
        $('#cormsfile').hide();


        $('#' + selectedValue).show();
    }
    var data = [

        { text: "Case", value: "C" },
        { text: "Record Folder", value: "F" },
        { text: "Correspondence", value: "CF" },
        { text: "Direct", value: "4" }
    ];

    // Initialize Kendo DropDownList
    $("#documentTypeDropDown").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: data,
        optionLabel: "Select One"
    });

    var letterTypeData = [
        { text: "Letter", value: "L" },
        { text: "Office Order", value: "OF" },
        { text: "Announcements", value: "A" },
        { text: "Reports", value: "R" }
    ];

    // Data for Security Level dropdown
    var securityLevelData = [
        { text: "Restricted", value: "R" },
        { text: "Unclassified", value: "U" }, // Changed value for Folder
        { text: "Confidential", value: "CF" },
        { text: "Secret", value: "S" }
    ];

    // Initialize Kendo DropDownList for Letter Type
    $("#letterTypeDropDown").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: letterTypeData
    });

    // Initialize Kendo DropDownList for Security Level
    $("#securityLevelDropDown").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: securityLevelData
    });
    var categoryData = [

        { text: "General", value: "G" },
        { text: "Staff", value: "S" },
        { text: "Site Feedback", value: "SF" }
    ];

    var otherDocumentTypeData = [
        { text: "Select One", value: "0" },
        { text: "PDF", value: "A" },
        { text: "DOC", value: "B" },
        { text: "JPG", value: "C" },
        { text: "PNG", value: "D" }

    ];



  
  
   
    
    
    


    // 
    // Initialize Kendo DropDownList for Other Document Type
    $("#otherDocumentTypeDropdown").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: otherDocumentTypeData
    });


    
   
   
   


    $("#multiselect").kendoMultiSelect({
        dataTextField: "tag",
        dataValueField: "Id",
        dataSource: dataSource,
        filter: "contains",
        placeholder: "Please select Tag",
        downArrow: true,
        noDataTemplate: $("#noDataTemplate").html(),

    });



    // Initialize Kendo DropDownList for Category
    $("#categoryDropDown").kendoDropDownList({
        dataTextField: "text",
        dataValueField: "value",
        dataSource: categoryData
    });
    // Initialize Kendo DropDownList for Category









    _UCCaseLinkGrid.CaseGridModalDocumentViewerId = '#modalMeetingCaseDocumentViewer';
    _UCCaseLinkGrid.CaseGridDocumentViewerId = 'caseMeetingDocumentViewerPopup';



});
$(function () {
    $("#sorucebox").change(function () {
        if ($(this).val() == "C") {
            $("#soruceselect").show();
            $("#soruceselectfolder").hide(); // Hide other select elements
            $("#soruceselectcp").hide();
            $("#sorucesec").hide();
        } else if ($(this).val() == "F") {
            $("#soruceselectfolder").show();
            $("#soruceselect").hide(); // Hide other select elements
            $("#soruceselectcp").hide();
            $("#sorucesec").hide();
        } else if ($(this).val() == "CP") {
            $("#soruceselectcp").show();
            $("#soruceselect").hide(); // Hide other select elements
            $("#soruceselectfolder").hide();
            $("#sorucesec").hide();
        }
    });
});




function addNew(widgetId, value) {
    var widget = $("#" + widgetId).getKendoMultiSelect();
    var dataSource = widget.dataSource;
    console.log(dataSource.length)
    dataSource.add({
        Id: dataSource.data().length + 1,
        tag: value
    });

    var currentValue = widget.value();
    currentValue.push(dataSource.data().length)
    widget.value(currentValue);
    widget.trigger("change");



};

var forum = [{

    Topic: "<a class='mb-0 font-15' href='forumtopicdetails.html'><b>Revenue sharing programs for consumers is a powerful marketing method</b></a><div class='mt-2'><a class='mb-0' href='forumtopicdetails.html'><b>Description:</b>In the previous post refer a friend programs were presented. The second type of programs which can be used to increase purchasing powers of consumers and keep them loyal is revenue sharing programs for customers (RSPs)..............</a></div><div class='d-flex align-items-center mt-2'><small class='staff'></small><p class='mb-0 font-12'>Staff, <b>Source:Case</b></p></div>",
    Null: "<div class='d-flex align-items-center'>   <i class='fa fa-gear mr-2'></i><div class='circle-yellow' ><p class='circle-inner'>C</p></div><small class='ml-2'>Chanan</small></div>",
    Repiles: 3,
    status: " Open",

    Activity: "1d",

}, {

    Topic: "<a class='mb-0 font-15' href='forumreopentopicdetails.html'><b>Would you please complete this Academic Research Survey on Minority Owned Small Businesses?</b></a><div class='mt-2'><a class='mb-0' href='forumreopentopicdetails.html'><b>Description:</b>Hi Guys! I am conducting a survey for an academic research project on minority owned small businesses. I would absolutely love to get your insights as this would help me tremendously with my research.............</a></div><div class='d-flex align-items-center mt-2'><small class='generalbook'></small><p class='mb-0 font-12'>Staff newtag, <b>Source:Correspondence</b></p></div>",
    Null: "<div class='d-flex align-items-center'><div class='circle-red' '><p class='circle-inner'>D</p></div><small class='ml-2'>Daaminah</small></div>",
    Repiles: 5,
    status: "Reopen",

    Activity: 17,

}, {
    Topic: "<a class='mb-0 font-15' href='forumclosedtopicdetails.html'><b>What’s the best book you’ve ever read?</b></a><div class='mt-2'><a class='mb-0' href='forumclosedtopicdetails.html'><b>Description:</b>What’s the best book you’ve ever read?........</a></div><div class='d-flex align-items-center mt-2'><small class='staff'></small><p class='mb-0 font-12'>General,<b>Source:Direct</b> </p></div>",
    Null: "<div class='d-flex align-items-center'>   <i class='fa fa-gear mr-2'></i><div class='circle-yellow' ><p class='circle-inner'>E</p></div><small class='ml-2'>Eemaan</small></div>",
    Repiles: 25,
    status: "Closed",

    Activity: "4h",


}, {
    Topic: "<a class='mb-0 font-15' href='forumtopicdetails.html'><b>Title of the topic</b></a><div class='mt-2'><a class='mb-0' href='forumtopicdetails.html'><b>Description:</b>Title of the topic.............</a></div><div class='d-flex align-items-baseline mt-2'><small class='generalbook'></small><p class='mb-0 font-12'>General book,<b>Source:Correspondence</b></p></div>",
    Null: "<div class='d-flex align-items-center'><div class='circle-green' ><p class='circle-inner'>A</p></div><small class='ml-2'>Adnan</small></div>",
    Repiles: 2,
    status: "Reopen",

    Activity: "5h",

},
{
    Topic: "<p class='mb-0 font-15' href='forumtopicdetails.html'><b>Admin Guide: Getting Starteds</b></p><div class='mt-2'><a class='mb-0' href='forumtopicdetails.html'><b>Description:</b>Admin Guide: Getting Starteds........</a></div><div class='d-flex align-items-center mt-2'><small class='generalbook'></small><p class='mb-0 font-12'>General book,<b>Source:Case</b></p></div>",
    Null: "<div class='d-flex align-items-center'><div class='circle-blue'><p class='circle-inner'>B</p></div><small class='ml-2'>Baasim</small></div>",
    Repiles: 21,
    status: "Reopen",

    Activity: "5d",


},
{
    Topic: "<p class='mb-0 font-15'><b>Admin Guide: Getting Started</b></p><div class='mt-2'><a class='mb-0' href='forumtopicdetails.html'><b>Description:</b>Admin Guide: Getting Starteds.......</a></div><div class='d-flex align-items-center mt-2'><small class='generalbook'></small><p class='mb-0 font-12'>Staff,<b>Source:Case</b></p></div>",
    Null: "<div class='d-flex align-items-center'><div class='circle-blue'><p class='circle-inner'>B</p></div><small class='ml-2'>Baasim</small></div>",
    Repiles: 1,
    status: "Reopen",

    Activity: "22d",


},
{
    Topic: "<p class='mb-0 font-15'><b>FAQ/Guidelines</b></p><div class='mt-2'><a class='mb-0' href='forumtopicdetails.html'><b>Description:</b>FAQ/Guidelines.......</a></div><div class='d-flex align-items-center mt-2'><small class='generalbook'></small><p class='mb-0 font-12'>Staff,<b>Source:Correspondence</b></p></div>",
    Null: "<div class='d-flex align-items-center'>   <i class='fa fa-gear mr-2'></i><div class='circle-yellow' ><p class='circle-inner'>E</p></div><small class='ml-2'>Eemaan</small></div>",
    Repiles: 1,

    status: "Reopen",
    Activity: "22d",


},
{
    Topic: "<p class='mb-0 font-15'><b>Title of the topic</b></p><div class='mt-2'><a class='mb-0' href='forumtopicdetails.html'><b>Description:</b>Title of the topic..........</a></div><div class='d-flex align-items-center mt-2'><small class='staff'></small><p class='mb-0 font-12'>General Staff newindia,<b>Source:Direct</b></p></div>",
    Null: "<div class='d-flex align-items-center'><div class='circle-blue'><p class='circle-inner'>B</p></div><small class='ml-2'>Baasim</small></div>",
    Repiles: 2,
    status: "Reopen",
    Activity: "21d",


},
];

/* outcome data */
var outcomedata = [{
    Categories: "<a  class='mb-0 font-15' >Resolved</a>",

    Outcome: "<a class='mb-0 font-15' href='forumtopicdetails.html'>Key takeaways and insights from the discussion are documented.</a>",
    // Null: "<div class='d-flex align-items-center'>   <i class='fa fa-gear mr-2'></i><div class='circle-yellow' ><p class='circle-inner'>C</p></div><small class='ml-2'>Chanan</small></div>",

    // Activity: "1d",

}, {
    Categories: "<a  class='mb-0 font-15' >Implemented</a>",


    Outcome: "<a class='mb-0 font-15' href='forumtopicdetails.html'>Participants identify specific steps or actions to be taken based on the discussion</a>",
    // Null: "<div class='d-flex align-items-center'><div class='circle-red' '><p class='circle-inner'>D</p></div><small class='ml-2'>Daaminah</small></div>",


    // Activity: 17,

}, {
    Categories: "<a  class='mb-0 font-15' >Off-Topic</a>",

    Outcome: "<a class='mb-0 font-15' href='forumtopicdetails.html'>Valuable content, insights generated during the discussion</a>",
    // Null: "<div class='d-flex align-items-center'>   <i class='fa fa-gear mr-2'></i><div class='circle-yellow' ><p class='circle-inner'>E</p></div><small class='ml-2'>Eemaan</small></div>",

    // Activity: "4h",


}



];





// function showFilter() {

//     $(".filterRow").toggle();
//     $(this).toggleClass('showFilter');
//     $("#filter").toggleClass('filterColor');
//     $("#filterRow").slideDown();
// }

function showFilter() {

    $(".filterRow").slideToggle('slow');
    $(this).toggleClass('showFilter');
    $("#filter").toggleClass('filterColor');

}

$("#showdocument").hide();
$("#documentnew").click(function () {
    $("#showdocument").show();

    $("#addtopic").hide();
})
$("#backbtndocument").click(function () {
    $("#showdocument").hide();

    $("#addtopic").show();
})
$("#addpoll").hide();
$("#btnpoll").click(function () {
    $("#addpoll").show();

    $("#addtopic").hide();
})

$("#backtotopic").click(function () {
    $("#addpoll").hide();

    $("#addtopic").show();
})

$('#Addinvite').hide();
$('#btnInvite').click(function () {
    $('#Addinvite').show();
    $('#addtopic').hide();
})

$('#backtoinvite').click(function () {
    $('#Addinvite').hide();
    $("#addtopic").show();
})

/* backto insert script */

$('#backtoinsert').click(function () {
    $("#poll-input").show();

    $("#voter-id").hide();
})

const options = document.querySelectorAll("label");
for (let i = 0; i < options.length; i++) {
    options[i].addEventListener("click", () => {
        for (let j = 0; j < options.length; j++) {
            if (options[j].classList.contains("selected")) {
                options[j].classList.remove("selected");
            }
        }

        options[i].classList.add("selected");
        for (let k = 0; k < options.length; k++) {
            options[k].classList.add("selectall");
        }

        let forVal = options[i].getAttribute("for");
        let selectInput = document.querySelector("#" + forVal);
        let getAtt = selectInput.getAttribute("type");
        if (getAtt == "checkbox") {
            selectInput.setAttribute("type", "radio");
        } else if (selectInput.checked == true) {
            options[i].classList.remove("selected");
            selectInput.setAttribute("type", "checkbox");
        }

        let array = [];
        for (let l = 0; l < options.length; l++) {
            if (options[l].classList.contains("selected")) {
                array.push(l);
            }
        }
        if (array.length == 0) {
            for (let m = 0; m < options.length; m++) {
                options[m].removeAttribute("class");
            }
        }
    });
}



$(document).ready(function () {
    $(".filterdetail").click(function () {
        $("#filterRow").slideDown("slow");
    });
});


// $(document).ready(function () {
//     $(".fld_set .check_blk input#editpost::checked").click(function () {
//         $(this).parent('.checked_lists').sibling('.fld_set').find(".check_blk1").addClass("show");
//     });
// });

function valueChanged() {
    if ($('#editpost').is(":checked")) {
        $(".check_blk1").show();
    }
    else {
        $(".check_blk1").hide();
    }
};

function valueChanged1() {
    if ($('#deletepost').is(":checked")) {
        $(".check_blk2").show();
    }
    else {
        $(".check_blk2").hide();
    }
};

function valueChanged2() {
    if ($('#ownreply').is(":checked")) {
        $(".check_blk3").show();
    }
    else {
        $(".check_blk3").hide();
    }
};

function valueChanged3() {
    if ($('#otherreply').is(":checked")) {
        $(".check_blk4").show();
    }
    else {
        $(".check_blk4").hide();
    }
};

function valueChanged4() {
    if ($('#deletereply').is(":checked")) {
        $(".check_blk5").show();
    }
    else {
        $(".check_blk5").hide();
    }
};

function participator1() {
    if ($('#editpost1').is(":checked")) {
        $(".parti-edit").show();
    }
    else {
        $(".parti-edit").hide();
    }
}

function participator2() {
    if ($('#deletepost1').is(":checked")) {
        $(".parti-delete").show();
    }
    else {
        $(".parti-delete").hide();
    }
}
function participator3() {
    if ($('#ownreply1').is(":checked")) {
        $(".parti-reply").show();
    }
    else {
        $(".parti-reply").hide();
    }
}

function participator4() {
    if ($('#otherreply1').is(":checked")) {
        $(".parti-other").show();
    }
    else {
        $(".parti-other").hide();
    }
}
function participator5() {
    if ($('#deletereply1').is(":checked")) {
        $(".parti-redelete").show();
    }
    else {
        $(".parti-redelete").hide();
    }
}
function ownerValue1() {
    if ($('#editpost3').is(":checked")) {
        $(".own-edit").show();
    }
    else {
        $(".own-edit").hide();
    }
}
function ownerValue2() {
    if ($('#deletepost3').is(":checked")) {
        $(".own-delete").show();
    }
    else {
        $(".own-delete").hide();
    }
}
function ownerValue3() {
    if ($('#ownreply3').is(":checked")) {
        $(".own-reply").show();
    }
    else {
        $(".own-reply").hide();
    }
}
function ownerValue4() {
    if ($('#otherreply3').is(":checked")) {
        $(".own-other").show();
    }
    else {
        $(".own-other").hide();
    }
}
function ownerValue5() {
    if ($('#deletereply3').is(":checked")) {
        $(".own-redelete").show();
    }
    else {
        $(".own-redelete").hide();
    }
}
// function valueChanged5() {
//     if($('#invitemember').is(":checked")) {
//       $(".check_blk6").show();
//     }
//     else {
//       $(".check_blk6").hide();
//     }
// };

// function valueChanged6() {
//     if($('#auditlog').is(":checked")) {
//       $(".check_blk7").show();
//     }
//     else {
//       $(".check_blk7").hide();
//     }
// };



