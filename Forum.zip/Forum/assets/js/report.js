



$(document).ready(function () {
  $("#grid").attr("aria-expanded", "true");
  var soruceboxData = [
    { text: "Select One", value: "0" },
    { text: "Case", value: "C" },
    { text: "Record Folder", value: "F" },
    { text: "Correspondence", value: "CP" },
    { text: "Direct", value: "D" }

  ];

  $("#sorucebox").kendoDropDownList({
    dataTextField: "text",
    dataValueField: "value",
    dataSource: soruceboxData
  });
  var dataSource = new kendo.data.DataSource({
    data: [
      { Id: 1, tag: "book" },
      { Id: 2, tag: "india" },
      { Id: 3, tag: "sample" },
      { Id: 4, tag: "newindia" },
      { Id: 5, tag: "books" },

    ],
    sort: { field: "tag", dir: "asc" }
  });
  $("#multiselecttag").kendoMultiSelect({
    dataTextField: "tag",
    dataValueField: "Id",
    dataSource: dataSource,
    filter: "contains",
    placeholder: "Please select Tag",
    downArrow: true,
    noDataTemplate: $("#noDataTemplate").html(),

  });
  $("#perdontag").kendoMultiSelect({
    autoClose: false
  });
  $("#datepicker").kendoDatePicker({
    dateInput: true
  });
  $("#datepickertodate").kendoDatePicker({
    dateInput: true
  });
  var statusData = [

    { text: "Open", value: "O" },
    { text: "Closed", value: "C" },
    { text: "Reopened", value: "RO" },
    { text: "Archived", value: "A" }

  ];
  $("#status").kendoDropDownList({
    dataTextField: "text",
    dataValueField: "value",
    dataSource: statusData
  });
  var categorysecData = [

    { text: "General", value: "G" },
    { text: "Staff", value: "S" },
    { text: "Site Feedback", value: "SF" }

  ];
  $("#categoryDropDown2").kendoDropDownList({
    dataTextField: "text",
    dataValueField: "value",
    dataSource: categorysecData
  });
  $("#grid").kendoGrid({

    dataSource: {
      type: "json",
      data: hierarchicalData,
      pageSize: 6,
      serverPaging: false,
      serverSorting: false,
      groupable: false,

    },
    height: 540,
    sortable: true,
    pageable: true,
    detailInit: detailInitCustomers,
    // dataBound: function () {
    //   this.expandRow(this.tbody.find("tr.k-master-row").first());

    // },
    // dataBound: function () {
    //   var grid = this;
    //   grid.tbody.find("tr.k-master-row").each(function () {
    //     grid.expandRow($(this));
    //   });
    // },
    dataBound:function  () {
      var grid = this;
      // Delay the expansion until all data is bound
      setTimeout(function () {
          grid.tbody.find("tr.k-master-row").each(function () {
              grid.expandRow($(this));
              var detailRow = $(this).next();
              if (detailRow.hasClass("k-detail-row")) {
                  detailRow.find("tr.k-detail-row").each(function () {
                      grid.expandRow($(this));
                  });
              }
          });
      });
  },
    
    
    columns: [
      {
        field: "threadtitle",
        title: "Thread Title",
        template: function (dataItem) {
          return dataItem.threadtitle;
        },

        // width: 300
      },
      
      {
        field: "source",
        title: "Source",
        template: function (dataItem) {
          return dataItem.source;
        }
      },
      {
        field: "category",
        title: "Category",
        template: function (dataItem) {
          return dataItem.category;
        }
      },
      {
        field: "tags",
        title: "Tags",

        template: function (dataItem) {
          return dataItem.tags;
        }
      },
      {
        field: "owner",
        title: "Owner",
        template: function (dataItem) {
          return dataItem.owner;
        }
      },
      {
        field: "createdat",
        title: "Created At",
        template: function (dataItem) {
          return dataItem.createdat;
        }
      },
      {
        field: "status",
        title: "Status",
        template: function (dataItem) {
          return dataItem.status;
        }
      },
      {
        field: "action",
        title: "Action",
        template: function (dataItem) {
          return dataItem.action;
        },
        // width: 82
      }
    ],

  });








 


});



// Initialize Kendo  add new tag 
function addNew(widgetId, value) {
  var widget = $("#" + widgetId).getKendoMultiSelect();
  var dataSource = widget.dataSource;
  console.log(dataSource.length)
  dataSource.add({
    Id: dataSource.data().length + 1,
    tag: value
  });

  var currentValue = widget.value();
  currentValue.push(dataSource.data().length)
  widget.value(currentValue);
  widget.trigger("change");



};
// TABLE SCRIPT
// function detailInit(e) {
//     $("<div/>").appendTo(e.detailCell).kendoGrid({

//       dataSource: {
//         type: "json",
//           data: customerData,
//         serverPaging: false,
//         serverSorting: false,
//         serverFiltering: false,
//         pageSize: 10,
//         // filter: { field: "EmployeeID", operator: "eq", value: e.data.EmployeeID }
//       },
//       detailInit: detailInitCustomers,
//       scrollable: false,
//       sortable: true,
//       pageable: true,
//       columns: [
//         { field: "user", title:"User Name", },
//         { field: "userid", title:"User ID",  },
//         { field: "country", title:"country" },

//       ],

//     });
//   }










function detailInitCustomers(e) {
  $("<div/>").appendTo(e.detailCell).kendoGrid({

    dataBound: function () {
      var grid = this;
      // Delay the expansion until all data is bound
      setTimeout(function () {
          grid.tbody.find("tr.k-master-row").each(function () {
              grid.expandRow($(this));
              var detailRow = $(this).next();
              if (detailRow.hasClass("k-detail-row")) {
                  detailRow.find("tr.k-detail-row").each(function () {
                      grid.expandRow($(this));
                  });
              }
          });
      });
  },
  
    
    dataSource: [

      {
        details: "Participants",
        Identify: [
          {
            "UserName": " Mohamad",
            "Role": "	Moderator",
            "Added on ": "18-Jan-24",
            "Invited by": "Ammer"
          },
          {
            "UserName": " Aryan",
            "Role": "	Owner",
            "Added on ": "15-Jan-24",
            "Invited by": "samir"
          },
        ]
      },
      {
        details: "Replies",
        Identify: [
          {
            "Reply": "Lorem Ipsum is simply dummy text of the printing and typesetting industry",
            "User": "Aaisha",
            "Replied On": "13-Jan-24 at 12.00 PM",

          },
          {
            "Reply": "It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged",
            "User": "Samir",
            "Replied On": "13-Jan-24 at 11.00 AM",

          }
        ]
      },




      {
        details: "Documents",
        Identify: [
          {
            "User": "Aafrin",
            "Role": "Owner",
            "Document Name": "Forum",
            "Document Type": "PDF",
            "Document": "www.linkforum.com"
          },
          {
            "User": "Nazeem",
            "Role": "Moderator",
            "Document Name": "SSL",
            "Document Type": "PDF",
            "Document": "https://forum.com"

          }
        ]
      },
      {
        details: "Audit Logs",
        Identify: [
          {
            "User": "Aafrin ",
            "Activity": "Reply to the comments at 18-Jan-24, 4:30AM",
            // "Edited Date": "18-Jan-24",
            // "Actual ReplyDate": "14-Jan-24",
            // "Replies": "Lorem Ipsum is simply dummy text of the printing and typesetting industry"
          },
          {
            "User": "Nazeem",
            "Activity": "Reacted to the post at 17-Jan-24, 7:30AM",
            // "Edited Date": "7-Jan-24",
            // "Actual ReplyDate": "14-Jan-24",
            // "Replies": "It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged"
          },
          {
            "User": "Mohamad",
            "Activity": "Added  the comments at 16-Jan-24, 10:00AM",
            // "Edited Date": "7-Jan-24",
            // "Actual ReplyDate": "14-Jan-24",
            // "Replies": "It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged"
          }
        ]
      },
      {
        details: "Outcome",
        Identify: [
          {
            "Categories": "Resolved",
            "Outcome": "Key takeaways and insights from the discussion are documented",
            // "Edited Date": "18-Jan-24",
            // "Actual ReplyDate": "14-Jan-24",
            // "Replies": "Lorem Ipsum is simply dummy text of the printing and typesetting industry"
          },
          {
            "Categories": "Implemented",
            "Outcome": "Participants identify specific steps or actins to be taken based on the discussion",
            // "Edited Date": "7-Jan-24",
            // "Actual ReplyDate": "14-Jan-24",
            // "Replies": "It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged"
          },
          {
            "Categories": "Off-Topic",
            "Outcome": "Valuable content,insights generated during the discussion",

            // "Edited Date": "7-Jan-24",
            // "Actual ReplyDate": "14-Jan-24",
            // "Replies": "It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged"
          }

        ]
      },


    
    ],





    detailTemplate: ' <div class="grid"></div>',
    

    detailInit: function (e) {
      e.detailRow.find(".grid").kendoGrid({
        dataSource: e.data.Identify,
        pageable: true,


      })
      
    },
    
    
    // dataBound: function () {
    //   var grid = this;
    //   // Delay the expansion until all data is bound
    //   setTimeout(function () {
    //     grid.tbody.find("tr.k-master-row").each(function () {
    //       grid.expandRow($(this));
    //     });
    //   });
    // },

   
    columns: [

      {
        field: "details", title:"More Details",
      },

    ],
    // dataBound: function () {
    //   var grid = this;
    //   // Delay the expansion until all data is bound
    //   setTimeout(function () {
    //     grid.tbody.find("tr.k-master-row").each(function () {
    //       grid.expandRow($(this));
    //     });
    //   });
    // },

  });


}






var hierarchicalData = [
  {
    "threadtitle": "<p class='mb-0 font-15 tablecoloumwidth ' ><b>Sample lorem ipsum is dummy text of the printing </b></a><div class='mt-2'><a class='mb-0 font-12' href='forumtopicdetails.html'><b>Description:</b> In the previous post refer a friend programs were presented. The second type of programs which can be used to increase purchasing powers of consumers and keep them loyal is revenue sharing programs for customers (RSPs).</p></div>",
    "owner": "Ammer",
    "repiles": "25",
    "tags": "<p style='word-wrap: break-word;'>Books,Author,Doc,Docall</p>",
    "category": "General Book",
    "source": "Case",
    "createdat": "24 Mar 2023, 6:45 pm",
    "status": "Closed",
    "action": '<a href="forumtopicdetails.html"  class="fa fa-eye"></a>'


  },
  {
    "threadtitle": "<p><b>Welcome to your 14 day basic hosting trial!</b></p>  <b>Description:</b>  <span class='font-12'>In the previous post refer a friend programs were presented. The second type of programs which can be used to increase purchasing powers of consumers and keep them loyal is revenue sharing programs for customers (RSPs).</span></p></div>",
    "owner": "Yousuf",
    "source": "Correspondence",
    "repiles": "25",
    "tags": "<p style='word-wrap: break-word;'>Books,Author,Doc,Docall</p>",
    "category": "Educational Book",
    "createdat": "25 Jun 2023, 9:00 am",
    "status": "Archived",
    "action": '<a href="forumtopicdetails.html"  class="fa fa-eye"></a>'
  },
  {
    "threadtitle": "<p><b>What’s the best book you’ve ever read?</b></p> <b>Description:</b> <span class='font-12'>In the previous post refer a friend programs were presented. The second type of programs which can be used to increase purchasing powers of consumers and keep them loyal is revenue sharing programs for customers (RSPs).</span></p></div>",
    "owner": "Imran",
    "source": "Case",
    "tags": "<p style='word-wrap: break-word;'>Business,Doc,Book,Author</p>",
    "category": "Adventure Book",
    "repiles": "1",
    "createdat": "2 Oct 2023, 10:45 pm",
    "status": "Open",
    "action": '<a href="forumtopicdetails.html"  class="fa fa-eye"></a>'
  },
  {
    "threadtitle": "<p> <b>Title of the topic</b> </p> <b>Description:</b> <span class='font-12'> In the previous post refer a friend programs were presented. The second type of programs which can be used to increase purchasing powers of consumers and keep them loyal is revenue sharing programs for customers (RSPs).</span></p></div>",
    "owner": "Abdullah",
    "source": "Direct",
    "tags": "<p style='word-wrap: break-word;'>Book,Owner,Doc,Product</p>",
    "category": "Book",
    "repiles": "15",
    "createdat": "4 Jan 2024, 11:05 am",
    "status": "Reopened",
    "action": '<a href="forumtopicdetails.html"  class="fa fa-eye"></a>'
  },
  


];
// var customerData = [
//   {
//     "user": "Aseem",
//     "userid": "4125",
//     "country": "Oman",


//   },
//   {
//     "user": "Muhammad",
//     "userid": "2536",
//     "country": "Oman",

//   },
//   {
//     "user": "Ishaaq",
//     "userid": "745",
//     "country": "Oman",

//   },
//   {
//     "user": "Zakariya",
//     "userid": "4586",
//     "country": "Wadi Shab",
//   },


// ];

// var repilesData = [
//   {
//     "datas": "Username",




//   },
//   {
//     "userreply": "Muhammad",
//     "replies": "Rohinton Mistry - A Fine Balance, Such a Long Journey",
//     "replieon": "4 Jan 2024, 1:05 pm"


//   },
//   {
//     "userreply": "Ishaaq",
//     "replies": "Vikram Seth- A Suitable Boy, Two Lives",
//     "replieon": "4 Jan 2024, 3:15 pm"

//   },
//   {
//     "userreply": "Zakariya",
//     "replies": "Lorem ipsum reply text text",
//     "replieon": "4 Jan 2024, 11:05 pm"
//   },


// ];
// Fileter



function showFilter() {
  $(".filterRow").slideToggle('slow');
  $(this).toggleClass('showFilter');
  $("#filter").toggleClass('filterColor');
}

