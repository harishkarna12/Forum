

 $(document).ready(function() {
 
        var people =[
          {
            ThreadTitle:"Owner ",
          },
          {
            ThreadTitle:"Moderator",
          },
          {
            ThreadTitle:"Participant",
          },
        ]
        $("#grid1").kendoGrid({
                columns: [
                    {
                        field: "ThreadTitle",
                        title: "Participants",
                    },
                    // {
                    //     field: "Author",
                    //     title: "Author",
                    // },
                    // {
                    //     field: "Source",
                    // },
                    // {
                    //     field: "Replies",
                    // },
                    // {
                    //     field: "CreatedAt",
                    //     title: "Created At",
                    // },
                    // {
                    //     field: "Status",
                    // },
                ],
                dataSource:{
                    data:people,
                    pageSize:7
                },
                scrollable:false,
                // pageable:2,
                detailInit: detailInit,
                dataBound: function() {
                    this.expandRow(this.tbody.find("tr.k-master-row").first());
                },
               
        });
      
         
          });
      // $(document.body).on('click', '#editpost', function(){
          
      //   });
        function detailInit(e) {
            var person =[
              {
                EditPost:"post1",
                DeletePost:"del post1",
                EditOwnReply:"Own reply1",
                EditOthersReply:"other reply",
                DeleteReply:"Del Reply",
                InviteOtherMembers:"Invite1",
                AuditLog:"Log1"
              },
            ]
            $("<div/>").appendTo(e.detailCell).kendoGrid({
              
                columns: [
                  // {
                  //   template: "<input type='checkbox' class='k-checkbox k-checkbox-md k-rounded-md checkbox' />",
                  //   width: 40,
                  //   attributes: {class: "k-text-center"}
                  // },
                  { 
                    field: "Edit Post", title:"Edit Post", width: "150px", template: "<input type='checkbox' class='k-checkbox checkshow k-checkbox-md k-rounded-md checkbox' id='editpost' name='gfdffd'  />" 
                  },
                  {
                    field: "DeletePost", title:"Delete Post", width: "150px", template: "<input type='checkbox' class='k-checkbox checkshow k-checkbox-md k-rounded-md checkbox' id='deletepost' name='vwgegege'/>" 
                  },
                  { 
                    field: "EditOwnReply", title: "Edit Own Reply", width: "150px", template: "<input type='checkbox' class='k-checkbox checkshow k-checkbox-md k-rounded-md checkbox' id='ownreply' onchange='valueShow3()' />" 
                  },
                  { 
                    field: "EditOthersReply", title: "Edit Others Reply", width: "150px", template: "<input type='checkbox' class='checkshow k-checkbox k-checkbox-md k-rounded-md checkbox' id='otherreply' onchange='valueShow4()' />" 
                  },
                  { 
                    field: "DeleteReply", title: "Delete Reply", width: "150px", template: "<input type='checkbox' class='checkshow k-checkbox k-checkbox-md k-rounded-md checkbox' id='deletereply' onchange='valueShow5()' />", attributes: {class: "k-text-center"} 
                  },
                  { 
                    field: "InviteOtherMembers", title: "Invite Other Members", width: "200px", template: "<input type='checkbox' class='checkshow k-checkbox k-checkbox-md k-rounded-md checkbox' id='invitemember' onchange='valueShow6()' />" 
                  },
                  { 
                    field: "AuditLog", title: "Audit Log", width: "150px", template: "<input type='checkbox' class='checkshow k-checkbox k-checkbox-md k-rounded-md checkbox' id='auditlog' onchange='valueShow7()' />" 
                  }
                ],
                dataSource:{
                    data:person,
                    // pageSize:7
                }
                // scrollable: false,
                // sortable: true,
                // pageable: true,
               
            });
        }

      // function valueShow() {
      //     if($('input').is(":checked")) { 
      //       $(".checked_lists").addClass('show'); 
      //       // $(".check_blk1").show();
      //     }
      //     else {
      //       // $(".check_blk1").hide();
      //       $(".checked_lists").removeClass('show'); 
      //     }
      // };
      $(function () {
        
        $(".checkshow").click(function () {
            // Reset visibility of all divs
            // $(".checked_lists h3").show(); 
            $('.check_blk1, .check_blk2, .check_blk3, .check_blk4, .check_blk5, .check_blk6, .check_blk7').hide();
            $(".checked_lists").addClass(); 
            // Check each checkbox individually
            if ($('#editpost').is(':checked')) {
              $('.check_blk1').show();
            }
            if ($('#deletepost').is(':checked')) {
              $(".check_blk2").show();
            }
            if ($('#ownreply').is(':checked')) {
              $(".check_blk3").show();
            }
            if ($('#otherreply').is(':checked')) {
              $(".check_blk4").show();
            }
            if ($('#deletereply').is(':checked')) {
              $(".check_blk5").show();
            }
            // if ($('#invitemember').is(':checked')) {
            //   $(".check_blk6").show();
            // }
            // if ($('#auditlog').is(':checked')) {
            //   $(".check_blk7").show();
            // }
            // Add more conditions for other checkboxes if needed
        });
    });